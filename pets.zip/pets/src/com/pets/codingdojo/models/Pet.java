package com.pets.codingdojo.models;

public interface Pet {
	public String showAffection();
}
